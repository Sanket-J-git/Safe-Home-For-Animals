package com.AniHome.AniHome.api;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AniHomeApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
