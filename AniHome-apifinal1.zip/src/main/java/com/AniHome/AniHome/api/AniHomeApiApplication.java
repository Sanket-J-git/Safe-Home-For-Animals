package com.AniHome.AniHome.api;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AniHomeApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(AniHomeApiApplication.class, args);
	}

}
