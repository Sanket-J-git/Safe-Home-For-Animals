import React from "react";
import MyNavbar from "../../components/MyNavbar/MyNavbar";

const NavBar = () => {
    return (
        <>
            <MyNavbar></MyNavbar>
        </>
    );
};

export default NavBar;