import React from "react";
import AboutUs from "../../components/AboutUs/AboutUs";

const AboutUsPage = () => {
    return (
        <>
            <AboutUs></AboutUs>
        </>
    );
};

export default AboutUsPage;