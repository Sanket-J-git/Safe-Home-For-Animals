import React from "react";
import Orders from "../../components/Orders/Orders";

const OrderPage = () => {
    return (
        <>
            <Orders></Orders>
        </>
    );
};

export default OrderPage;