import React from "react";
import AddAnimal from "../../components/Animal/AddAnimal";

const AddAni = () => {
  return (
    <>
      <AddAnimal></AddAnimal>
    </>
  );
};

export default AddAni;
