import React from "react";
import VoiceSearch from "../../components/VoiceSearch/VoiceSerach";

const SearchPage = () => {
    return (
        <>
            <VoiceSearch></VoiceSearch>
        </>
    );
}

export default SearchPage;