import React from "react";
import RescAppointments from "../../components/Appointments/RescAppointments";

const ResAppoint = () => {
  return (
    <>
      <RescAppointments></RescAppointments>
    </>
  );
};

export default ResAppoint;
