import React from "react";
import AddAppointment from "../../components/Appointments/AddAppointment";

const AddAppoint = () => {
  return (
    <>
      <AddAppointment></AddAppointment>
    </>
  );
};

export default AddAppoint;
