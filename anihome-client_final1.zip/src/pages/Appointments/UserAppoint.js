import React from "react";
import UserAppointments from "../../components/Appointments/UserAppointments";

const UserAppoint = () => {
  return (
    <>
      <UserAppointments></UserAppointments>
    </>
  );
};

export default UserAppoint;
