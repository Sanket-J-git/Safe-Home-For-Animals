import React from "react";
import AddOrder from "../../components/Orders/AddOrder";

const AddOrd = () => {
  return (
    <>
      <AddOrder></AddOrder>
    </>
  );
};

export default AddOrd;
