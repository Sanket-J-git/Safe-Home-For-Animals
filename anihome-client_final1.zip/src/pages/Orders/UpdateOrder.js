import React from "react";
import UpdateOrder from "../../components/Orders/UpdateOrder";

const UpdateOrd = () => {
  return (
    <>
      <UpdateOrder></UpdateOrder>
    </>
  );
};

export default UpdateOrd;
