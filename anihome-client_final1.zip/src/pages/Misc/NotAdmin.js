import React from "react";

const NotAdmin = () => {
  return (
    <>
      <div>
        <div
          style={{
            padding: "5% 5%",
            backgroundImage: `url("https://garden.spoonflower.com/c/13024598/p/f/m/Tp3Q8mLxFCgbRU0Jbm8Pse_UIY7Uys5g5MOkTeKCI1BBej24oLMYHw_CKpJi/The%20minimalist%20dog%20paws%20sweet%20pet%20lovers%20boho%20style%20paw%20design%20in%20white%20on%20moody%20blue.jpg")`,
            backgroundRepeat: "repeat",
            backgroundSize: "contain",
            backgroundPosition: "center",
          }}
        >
          <h1
            className="d-flex justify-content-center"
            style={{ padding: "50px 0px" }}
          >
            Oops! 403 Forbidden Error
          </h1>
          <h1
            className="d-flex justify-content-center"
            style={{ padding: "50px 0px" }}
          >
            Please Login As Admin!
          </h1>
        </div>
      </div>
    </>
  );
};

export default NotAdmin;
