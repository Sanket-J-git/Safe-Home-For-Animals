import React from "react";
import AddComplaint from "../../components/Complaints/AddComplaint";

const AddComp = () => {
  return (
    <>
      <AddComplaint></AddComplaint>
    </>
  );
};

export default AddComp;
