import React from "react";
import ResComp from "../../components/Complaints/ResComp";

const ResCompPage = () => {
    return (
        <>
            <ResComp></ResComp>
        </>
    );
};

export default ResCompPage;