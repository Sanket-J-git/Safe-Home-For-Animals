import React from "react";
import UpdateComplaint from "../../components/Complaints/UpdateComplaint";

const UpdateComp = () => {
  return (
    <>
      <UpdateComplaint></UpdateComplaint>
    </>
  );
};

export default UpdateComp;
