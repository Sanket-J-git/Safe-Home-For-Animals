import React from "react";
import Complaints from "../../components/Complaints/Complaints";

const ComplaintsPage = () => {
    return (
        <>
            <Complaints></Complaints>
        </>
    );
};

export default ComplaintsPage;