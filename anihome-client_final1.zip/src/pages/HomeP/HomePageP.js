import React from "react";
import HomePage from "../../components/HomePage/HomePage";

const HomePageP = () => {
    return (
        <>
            <HomePage></HomePage>
        </>
    );
};

export default HomePageP;