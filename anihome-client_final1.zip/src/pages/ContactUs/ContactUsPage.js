import React from "react";
import { ContactUs } from "../../components/ContactUs/ContactUs";

const ContactUsPage = () => {
    return (
        <>
            <ContactUs></ContactUs>
        </>
    );
};

export default ContactUsPage;