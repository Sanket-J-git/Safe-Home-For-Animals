import React from "react";
import AllContactUs from "../../components/ContactUs/AllContactUs";

const AllContact = () => {
  return (
    <>
      <AllContactUs></AllContactUs>
    </>
  );
};

export default AllContact;
