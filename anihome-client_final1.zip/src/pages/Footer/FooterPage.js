import React from "react";
import Footer from "../../components/Footer/Footer";

const FooterPage = () => {
    return (
        <>
            <Footer></Footer>
        </>
    );
};

export default FooterPage;