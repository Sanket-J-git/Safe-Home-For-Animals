import React from "react";
import UserProfile from "../../components/Registration/UserProfile";

const ProfilePage = () => {
  return (
    <>
      <UserProfile></UserProfile>
    </>
  );
};

export default ProfilePage;
