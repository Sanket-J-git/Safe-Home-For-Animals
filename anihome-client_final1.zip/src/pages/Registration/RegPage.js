import React from "react";
import Register from "../../components/Registration/Register";

const RegPage = () => {
  return (
    <>
      <Register></Register>
    </>
  );
};

export default RegPage;
