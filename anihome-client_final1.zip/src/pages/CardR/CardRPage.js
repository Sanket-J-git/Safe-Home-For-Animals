import React from "react";
import CardR from "../../components/CardR/CardR";

const CardRPage = () => {
    return (
        <>
            <CardR></CardR>
        </>
    );
};

export default CardRPage;