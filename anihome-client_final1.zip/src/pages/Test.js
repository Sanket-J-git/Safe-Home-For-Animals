import React from "react";
import AniBot from "../components/AniBot/AniBot";
import VoiceSearch from "../components/VoiceSearch/VoiceSerach";

const Test = () => {
  return (
    <>
      <VoiceSearch></VoiceSearch>
      <AniBot></AniBot>
    </>
  );
};

export default Test;
