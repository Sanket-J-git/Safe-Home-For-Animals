import React from 'react';
import Feedback from '../../components/Feedback/Feedback';

const FeedPage = () => {
    return (
        <>
            <Feedback></Feedback>
        </>
    );
}

export default FeedPage;