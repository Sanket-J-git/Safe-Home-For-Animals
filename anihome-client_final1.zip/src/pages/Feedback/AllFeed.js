import React from "react";
import AllFeedbacks from "../../components/Feedback/AllFeedbacks";

const AllFeed = () => {
  return (
    <>
      <AllFeedbacks></AllFeedbacks>
    </>
  );
};

export default AllFeed;
